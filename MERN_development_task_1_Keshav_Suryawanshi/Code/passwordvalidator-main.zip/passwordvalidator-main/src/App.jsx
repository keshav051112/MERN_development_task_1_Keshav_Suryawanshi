import React, { useState } from "react";

const App = () => {
  const [password, setPassword] = useState("");
  const [strength, setStrength] = useState("");

  const evaluateStrength = (password) => {
    let score = 0;

    
    if (/[a-z]/.test(password)) score += 1; // Lowercase
    if (/[A-Z]/.test(password)) score += 1; // Uppercase
    if (/[0-9]/.test(password)) score += 1; // Numbers
    if (/[^a-zA-Z0-9]/.test(password)) score += 1; // Special characters

   
    if (password.length >= 8) score += 1; // Good length

   
    if (score <= 2) {
      return "Weak";
    } else if (score === 3) {
      return "Good";
    } else if (score === 4) {
      return "Very Good";
    } else if (score === 5) {
      return "Excellent";
    }
  };

  const handlePasswordChange = (e) => {
    const input = e.target.value;
    setPassword(input);
    setStrength(evaluateStrength(input));
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-100">
      <h1 className="text-2xl mb-8 font-semibold text-blue-600">check the strength of password</h1>
      <div className="bg-white shadow-lg rounded-lg p-8 w-96">
        <h2 className="text-2xl font-bold text-gray-800 mb-6 text-center">
          Password Validator
        </h2>
        <input
          type="password"
          value={password}
          onChange={handlePasswordChange}
          placeholder="Enter your password"
          className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
        />
        <p className="text-center text-lg">
          Password Strength:{" "}
          <span
            className={`font-semibold ${
              strength === "Weak"
                ? "text-red-500"
                : strength === "Good"
                ? "text-yellow-500"
                : strength === "Very Good"
                ? "text-blue-500"
                : strength === "Excellent"
                ? "text-green-500"
                : "text-gray-500"
            }`}
          >
            {strength || "N/A"}
          </span>
        </p>
      </div>
    </div>
  );
};

export default App;
